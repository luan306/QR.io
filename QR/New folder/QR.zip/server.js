import express from "express";
import mysql from "mysql2/promise";
import bodyParser from "body-parser";
import cors from "cors";
import multer from "multer"; 
import XLSX from "xlsx";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Thêm cấu hình EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public')); // Thêm static files

// Cấu hình multer cho upload file
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/') // Make sure this folder exists
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
  }
})

const upload = multer({ storage: storage })

// Create uploads directory if it doesn't exist
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads')
}

// 🔧 Cấu hình database MySQL
const dbConfig = {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
};

async function getConnection() {
  return await mysql.createConnection(dbConfig);
}

// ✅ API test
app.get("/", (req, res) => {
  res.send("✅ Asset Manager API chạy rồi!");
});

// Route cho trang chủ
app.get('/', (req, res) => {
  res.render('index');
});

// Route cho trang login 
app.get('/login', (req, res) => {
  res.render('login');
});

// Route cho trang admin
app.get('/admin', (req, res) => {
  res.render('admin');
});

// 🔑 Đăng nhập
app.post("/api/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    const conn = await getConnection();

    const [rows] = await conn.execute(
      "SELECT * FROM users WHERE username=? AND password=?",
      [username, password]
    );
    await conn.end();

    if (rows.length > 0) {
      res.json({ success: true, user: rows[0] });
    } else {
      res.json({ success: false, message: "Sai tài khoản hoặc mật khẩu" });
    }
  } catch (err) {
    console.error("❌ Lỗi login:", err.message);
    res.status(500).json({ success: false, message: "Lỗi server!" });
  }
});


// 📦 Lấy danh sách thiết bị theo bộ phận
app.get("/api/devices/:deptId", async (req, res) => {
  try {
    const { deptId } = req.params;
    const conn = await getConnection();

    const [rows] = await conn.execute(
      "SELECT * FROM devices WHERE department_id=?",
      [deptId]
    );

    await conn.end();
    res.json(rows);
  } catch (err) {
    console.error("❌ Lỗi lấy danh sách devices:", err.message);
    res.status(500).json({ success: false, message: "Lỗi server!" });
  }
});


// 📷 Quét QR thiết bị
app.post("/api/scan", async (req, res) => {
  try {
    const { user_id, qr_code } = req.body;
    const conn = await getConnection();

    const serial = qr_code.split("$")[0]; // ⚡ lấy phần trước dấu `$`

    const [devices] = await conn.execute(
      "SELECT * FROM devices WHERE qr_code=?",
      [serial]
    );

    if (devices.length === 0) {
      await conn.end();
      return res.json({ success: false, message: "Không tìm thấy thiết bị!" });
    }

    const device_id = devices[0].id;

    const [scanned] = await conn.execute(
      "SELECT * FROM scans WHERE device_id=? AND user_id=?",
      [device_id, user_id]
    );

    if (scanned.length > 0) {
      await conn.end();
      return res.json({
        success: false,
        already: true,
        message: "⚠️ Thiết bị này đã được quét rồi!",
        device: devices[0],
      });
    }

    await conn.execute(
      "INSERT INTO scans (user_id, device_id) VALUES (?, ?)",
      [user_id, device_id]
    );

    await conn.end();

    res.json({
      success: true,
      message: "✅ Đã quét thành công!",
      device: devices[0],
    });
  } catch (err) {
    console.error("❌ Lỗi scan:", err.message);
    res.status(500).json({ success: false, message: "Lỗi server!" });
  }
});


// 📋 Lấy tất cả lịch sử quét
app.get("/api/scans", async (req, res) => {
  try {
    const conn = await getConnection();
    const [rows] = await conn.execute(`
      SELECT scans.id, scans.scanned_at,
             devices.id AS device_id, devices.name AS device_name, devices.qr_code,
             users.id AS user_id, users.full_name AS user_name
      FROM scans
      JOIN devices ON scans.device_id = devices.id
      JOIN users ON scans.user_id = users.id
      ORDER BY scans.scanned_at DESC
    `);
    await conn.end();
    res.json(rows);
  } catch (err) {
    console.error("❌ Lỗi lấy scans:", err.message);
    res.status(500).json({ message: "Lỗi server khi lấy scans" });
  }
});


// 🏢 Lấy danh sách bộ phận
app.get("/api/departments", async (req, res) => {
  try {
    const conn = await getConnection();
    const [rows] = await conn.execute("SELECT id, name FROM departments");
    await conn.end();
    res.json(rows);
  } catch (err) {
    console.error("❌ Lỗi lấy bộ phận:", err.message);
    res.status(500).json({ message: "Lỗi server" });
  }
});


// 💻 Lấy danh sách loại thiết bị
app.get("/api/device-types", async (req, res) => {
  try {
    const conn = await getConnection();
    const [rows] = await conn.execute("SELECT id, name FROM device_types");
    await conn.end();
    res.json(rows);
  } catch (err) {
    console.error("❌ Lỗi lấy loại thiết bị:", err.message);
    res.status(500).json({ message: "Lỗi server" });
  }
});


// 📌 Quản lý User
app.get("/api/users", async (req, res) => {
  try {
    const conn = await getConnection();
    const [rows] = await conn.execute(
      "SELECT id, username, full_name, role FROM users"
    );
    await conn.end();
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Lỗi server" });
  }
});

app.post("/api/users", async (req, res) => {
  try {
    const { username, password, full_name, department_id, role } = req.body;
    const conn = await getConnection();
    await conn.execute(
      "INSERT INTO users (username, password, full_name, department_id, role) VALUES (?,?,?,?,?)",
      [username, password, full_name, department_id, role || "user"]
    );
    await conn.end();
    res.json({ success: true, message: "Tạo user thành công!" });
  } catch (err) {
    res.status(500).json({ message: "Lỗi server" });
  }
});

app.put("/api/users/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { full_name, department_id, role, password } = req.body;
    const conn = await getConnection();

    if (password && password.trim() !== "") {
      await conn.execute(
        "UPDATE users SET full_name=?, department_id=?, role=?, password=? WHERE id=?",
        [full_name, department_id, role, password, id]
      );
    } else {
      await conn.execute(
        "UPDATE users SET full_name=?, department_id=?, role=? WHERE id=?",
        [full_name, department_id, role, id]
      );
    }

    await conn.end();
    res.json({ success: true, message: "✅ Cập nhật user thành công" });
  } catch (err) {
    console.error("❌ Lỗi update user:", err.message);
    res.status(500).json({ success: false, message: "Lỗi server" });
  }
});


// 📊 Thống kê theo bộ phận
app.get("/api/stats/departments", async (req, res) => {
  try {
    const conn = await getConnection();
    const [rows] = await conn.execute(`
      SELECT 
        d.id AS department_id,
        d.name AS department_name,
        COUNT(dev.id) AS total_devices,
        COUNT(DISTINCT s.device_id) AS scanned_devices
      FROM departments d
      LEFT JOIN devices dev ON dev.department_id = d.id
      LEFT JOIN scans s ON s.device_id = dev.id
      GROUP BY d.id, d.name
      ORDER BY d.name
    `);
    await conn.end();

    const result = rows.map(r => ({
      ...r,
      pending_devices: r.total_devices - r.scanned_devices,
    }));

    res.json(result);
  } catch (err) {
    console.error("❌ Lỗi thống kê bộ phận:", err.message);
    res.status(500).json({ message: "Lỗi server khi thống kê bộ phận" });
  }
});


// 📋 Thiết bị theo bộ phận + trạng thái
app.get("/api/departments/:id/devices", async (req, res) => {
  try {
    const { id } = req.params;
    const conn = await getConnection();
    const [rows] = await conn.execute(`
      SELECT 
        dev.id, dev.qr_code, dev.name, dev.location,
        CASE WHEN s.id IS NULL THEN 'Chưa quét' ELSE 'Đã quét' END AS status
      FROM devices dev
      LEFT JOIN scans s ON s.device_id = dev.id
      WHERE dev.department_id = ?
    `, [id]);
    await conn.end();
    res.json(rows);
  } catch (err) {
    console.error("❌ Lỗi lấy thiết bị theo bộ phận:", err.message);
    res.status(500).json({ message: "Lỗi server!" });
  }
});


// 📤 Upload Excel -> Import devices
app.post("/api/devices/upload", upload.single("file"), async (req, res) => {
  try {
    const workbook = XLSX.readFile(req.file.path);
    const sheetName = workbook.SheetNames[0];
    const sheet = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

    const conn = await getConnection();

    for (let row of sheet) {
      // Lấy hoặc tạo department
      let [dept] = await conn.execute(
        "SELECT id FROM departments WHERE name = ?",
        [row.Department]
      );

      let deptId;
      if (dept.length > 0) {
        deptId = dept[0].id;
      } else {
        const [result] = await conn.execute(
          "INSERT INTO departments (name) VALUES (?)",
          [row.Department]
        );
        deptId = result.insertId; // Lấy id bộ phận mới
      }

      // Thêm hoặc cập nhật thiết bị
      await conn.execute(
        `INSERT INTO devices (name, qr_code, department_id) 
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE 
           name = VALUES(name), 
           department_id = VALUES(department_id)`,
        [row.Name, row.QR_Code, deptId]
      );
    }

    await conn.end();

    res.json({ success: true, message: "✅ Import Excel thành công, bộ phận cũng được thêm nếu chưa có!" });
  } catch (err) {
    console.error("❌ Lỗi import Excel:", err);
    res.status(500).json({ success: false, message: "Lỗi server khi import Excel" });
  }
});



// 📥 Xuất Excel danh sách thiết bị
app.get("/api/devices/export", async (req, res) => {
  try {
    const conn = await getConnection();
    const [rows] = await conn.execute(`
      SELECT 
        d.id, d.name, d.qr_code, d.location,
        dep.name AS department_name
      FROM devices d
      LEFT JOIN departments dep ON d.department_id = dep.id
    `);
    await conn.end();

    // Chuyển dữ liệu sang worksheet
    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Devices");

    // Tạo file tạm
    const exportPath = path.join(__dirname, "devices_export.xlsx");
    XLSX.writeFile(workbook, exportPath);

    // Gửi file về client
    res.download(exportPath, "devices.xlsx", err => {
      if (err) console.error("❌ Lỗi tải file:", err);
      fs.unlinkSync(exportPath); // Xóa file tạm sau khi tải
    });
  } catch (err) {
    console.error("❌ Lỗi export Excel:", err.message);
    res.status(500).json({ success: false, message: "Lỗi server khi export Excel" });
  }
});


// 📌 API lấy tất cả devices (có tên bộ phận + trạng thái)
app.get("/api/devices", async (req, res) => {
  try {
    const conn = await getConnection();
    const [rows] = await conn.execute(`
      SELECT 
        d.id, d.name, d.qr_code, d.location, 
        dep.name AS department_name,
        CASE WHEN s.id IS NULL THEN 'Chưa quét' ELSE 'Đã quét' END AS status
      FROM devices d
      LEFT JOIN departments dep ON d.department_id = dep.id
      LEFT JOIN scans s ON s.device_id = d.id
    `);
    await conn.end();

    res.json(rows);
  } catch (err) {
    console.error("❌ Lỗi lấy thiết bị:", err.message);
    res.status(500).json({ success: false, message: "Lỗi server" });
  }
});


// ❌ Xóa toàn bộ scans
app.delete("/api/scans", async (req, res) => {
  try {
    const conn = await getConnection();
    await conn.execute("DELETE FROM scans");
    await conn.end();
    res.json({ success: true, message: "Đã xóa toàn bộ báo cáo!" });
  } catch (err) {
    console.error("❌ Lỗi xóa scans:", err.message);
    res.status(500).json({ success: false, message: "Lỗi khi xóa báo cáo" });
  }
});
// ❌ Xóa 1 thiết bị theo id
app.delete("/api/devices/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const conn = await getConnection();

    // Xóa liên kết trong scans trước để tránh lỗi ràng buộc
    await conn.execute("DELETE FROM scans WHERE device_id = ?", [id]);
    await conn.execute("DELETE FROM devices WHERE id = ?", [id]);

    await conn.end();
    res.json({ success: true, message: "✅ Đã xóa thiết bị!" });
  } catch (err) {
    console.error("❌ Lỗi xóa thiết bị:", err.message);
    res.status(500).json({ success: false, message: "Lỗi server khi xóa thiết bị" });
  }
});
// ❌ Xóa toàn bộ thiết bị
app.delete("/api/devices", async (req, res) => {
  try {
    const conn = await getConnection();

    // Xóa scans trước
    await conn.execute("DELETE FROM scans");
    await conn.execute("DELETE FROM devices");

    await conn.end();
    res.json({ success: true, message: "✅ Đã xóa toàn bộ thiết bị!" });
  } catch (err) {
    console.error("❌ Lỗi xóa tất cả thiết bị:", err.message);
    res.status(500).json({ success: false, message: "Lỗi server khi xóa tất cả thiết bị" });
  }
});


// 🚀 Chạy server
const port = process.env.PORT || 3000;
if (process.env.NODE_ENV !== 'test') {
  app.listen(port, () => {
    console.log(`🚀 API chạy tại http://${process.env.HOST}:${port}`);
  });
}

export default app;
